#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_STR 32
#define MAX_VEHICLES 4
#define MAX_CUSTOMERS 6

//Defining Structures:

//Vehicle Structre
typedef struct {
  char make[MAX_STR];
  char model[MAX_STR];
  char colour[MAX_STR];
  int year;
  int mileage;
} VehicleType;

//CustomerTy[e structure
typedef struct {
  char firstName[MAX_STR];
  char lastName[MAX_STR];
  int numVehicle;
  VehicleType ownedVehicles[MAX_VEHICLES];
} CustomerType;

//Functions://

//Print Vehicle function
//In: Pointer to a vehicle type
//out: none
//Purpose: print a vehicle info
void print_vehicle(VehicleType *v) {
  printf("%d %s %s, %s, %dKM\n", v->year, v->make, v->model, v->colour, v->mileage);
}

//Print Customer function
//In: Pointer to a customer typ
//out: none
//Purpose: prit a customers info
void print_customer(CustomerType *c) {
  printf("%s %s, %d vehicle(s)\n", c->firstName, c->lastName, c->numVehicle);     for(int i =0; i<(c->numVehicle); i++){
    print_vehicle(&(c->ownedVehicles[i]));
  }
}

//Add Vehicle function
//In: Pointer to a vehicle type
//out: 0: if customer doesn't have max vehicles
// -1: if customer has max vehicles
//Purpose: add a vehicle to a customer
int add_vehicle(CustomerType *customer, VehicleType *vehicle) {
  if(customer->numVehicle < MAX_VEHICLES){  
    customer->ownedVehicles[customer->numVehicle] = *vehicle;
    customer->numVehicle++;
    return 0;
  }
  return -1;
}

//Create a customer type
//In: customers first and last names
//out: returns a customr
//Purpose: create a customer
CustomerType create_customer(char* fname, char* lname) {
  CustomerType *c = (CustomerType*)malloc(sizeof(CustomerType));
  strcpy(c->firstName, fname);
  strcpy(c->lastName, lname);
  c->numVehicle=0;
  return *c;
}

//Make a vehicle type
//In: vehicles make, model, colour, year and mileage
//out: returns a vehicle type
//Purpose: create a vehicle type
VehicleType create_vehicle(char* make, char* model, char* colour,
                            int year, int mileage) {
  VehicleType *v = NULL;
  v = (VehicleType*)malloc(sizeof(VehicleType));
  strcpy(v->make, make);
  strcpy(v->model, model);
  strcpy(v->colour, colour);
  v->year = year;
  v->mileage = mileage;
  return *v;
}


int main() {

  //Making Customers and adding vehicles to their structures:
  CustomerType customers[MAX_CUSTOMERS];
  customers[0] = create_customer("Maurice", "Mooney");
  VehicleType v1 = create_vehicle("Ford", "Fiesta", "Red", 2007, 100000);
  add_vehicle(&customers[0], &v1);
  
  customers[1] = create_customer("Abigail", "Atwood");
  VehicleType v2 = create_vehicle("Subaru", "Forester", "Green", 2016, 40000);
  add_vehicle(&customers[1], &v2);
  
  customers[2] = create_customer("Brook", "Banding");
  VehicleType v3 = create_vehicle("Honda", "Accord", "White", 2018, 5000);
  add_vehicle(&customers[2], &v3);
  VehicleType v4 = create_vehicle("Volkswagen", "Beetle", "White", 1972, 5000);
  add_vehicle(&customers[2], &v4);
  
  customers[3] = create_customer("Ethan", "Esser");
  VehicleType v5 = create_vehicle("Toyota", "Camry", "Black", 2010, 50000);
  add_vehicle(&customers[3], &v5);
  
  customers[4] = create_customer("Eve", "Engram");
  VehicleType v6 = create_vehicle("Toyota", "Corolla", "Green", 2013, 80000);
  add_vehicle(&customers[4], &v6);
  VehicleType v7 = create_vehicle("Toyota", "Rav4", "Gold", 2015, 20000);
  add_vehicle(&customers[4], &v7);
  VehicleType v8 = create_vehicle("Toyota", "Prius", "Blue",2017, 10000);
  add_vehicle(&customers[4], &v8);
  
  customers[5] = create_customer("Victor", "Vanvalkenburg");
  VehicleType v9 = create_vehicle("GM", "Envoy", "Purple", 2012, 60000);
  add_vehicle(&customers[5], &v9);
  VehicleType v10 = create_vehicle("GM", "Escalade", "Black", 2016, 40000);
  add_vehicle(&customers[5], &v10);
  VehicleType v11 = create_vehicle("GM", "Malibu", "Red", 2015, 20000);
  add_vehicle(&customers[5], &v11);
  VehicleType v12 = create_vehicle("GM", "Trailblazer", "Orange", 2012, 90000);
  add_vehicle(&customers[5], &v12);
  VehicleType v13 = create_vehicle("Magic Dragon", "Puff", "Turqoise", 1000, 56);
  add_vehicle(&customers[5], &v13);

  //Printing out the Customers
  for(int i =0; i<MAX_CUSTOMERS;i++){
    printf("\n");
    print_customer(&customers[i]);
  }

  return 0;
}

