#include <sstream>
#include <iomanip>
#include <iostream>
#include <string>
using namespace std;
#include "View.h"
#include "CustomerList.h"
#include "Customer.h"
#include "VehicleList.h"
#include "Vehicle.h"
#include "Shop.h"

void View::mainMenu(int& choice) const {
    string str;

    choice = -1;

    cout<< "\n\n\n         **** Toby's Auto Mechanic Information Management System ****\n\n";
    cout<< "                                 MAIN MENU\n\n";
    cout<< "        3. Add a Vehicle to an Existing Customer\n\n";
    cout<< "        2. Add a Customer to the Database\n\n";
    cout<< "        1. Print Customer Database\n\n";
    cout<< "        0. Exit\n\n";

    while (choice < 0 || choice > 3) {
        cout << "Enter your selection:  ";
        choice = readInt();
    }
    if (choice == 0) { cout << endl; }
    if (choice == 2) {
		cout<< "Please Enter Information About the Customer to be Added" << endl;
	}
	if (choice == 3) {
		cout << "Please Enter a Customer I.D. to Add a Vehicle" << endl;
	}
}

//Name: printCustomers
//in: CustomerList
//out: prints customers
//Purpose: prints customers
void View::printCustomers(CustomerList& arr)  {
	//Our ultimate output string
	string printOut = "";
	string& outStr = printOut;
		
    cout << endl << "CUSTOMERS: " << endl << endl;
    arr.toString(outStr);
    cout << outStr << endl;	     
}

//prof made
void View::pause() const{
    string str;
    
    cout << "Press enter to continue...";
    getline(cin, str);
}

//Prof made
int View::readInt()const {
    string str;
    int    num;

    getline(cin, str);
    stringstream ss(str);
    ss >> num;

    return num;
}

//Name: readInputCust
//in: attributes of customer
//out: stores data into inputed strings
//Purpose: read input into customer attributes to be use to make a customer
void View::readInputCust(string *fName, string *lName, string *address, string *pNumber)const{
	
	cout<< "Please enter the first name!" <<endl;
	getline(cin, *fName);
	
	cout<< "Please enter the last name!" <<endl;
	getline(cin, *lName);
	
	cout<< "Please enter an address"<<endl;
	getline(cin, *address);
	
	cout<< "Please enter a Phone Number" << endl;
	getline(cin, *pNumber);
}

//Name: readInputVehicle
//in: attributes of vehicle, and our shop object.
//out: returns id, as well as fills the input vehicle attributes
//Purpose: read input and store into vehicle attributes to use in making a vehicle
int View::readInputVehicle(Shop& shop, string* make, string* model, int* year, string* colour, int* mileage)const{
	int id;
	id = readInt();
	if (shop.getCustomer(id)!=NULL){
			
			cout<<"Please Enter the Make:"<< endl;
			getline(cin, *make);
			
			cout<<"Please Enter the Model:"<< endl;
			getline(cin,*model);
			
			cout<<"Please Enter the Year:"<< endl;
			*year = readInt();
			
			cout<<"Please Enter the Colour:"<< endl;
			getline(cin,*colour);
			
			cout<<"Please Enter the Mileage:"<< endl;
			*mileage = readInt();
			return id;	
		}
	
	cout<<"Sorry, a Customer With that I.D. isn't in our Database"<<endl;
	return 0;
}
