#include "VehicleList.h"
#include  <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

VehicleList::VehicleList(): head(0) {}

VehicleList:: ~VehicleList(){
  Node *currNode, *nextNode;
  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }		
}

//Name:  add
//in: vehicle pointer
//out: n/a
//Purpose: radd a vehicle to the list
void VehicleList:: add(Vehicle* vehic){
  Node* tmpNode = new Node;
  tmpNode->data = vehic;
  tmpNode->next = 0;

  Node *currNode, *prevNode =0;

  currNode = head;

  if(currNode !=0){
    while (currNode != 0) { 
      if (currNode->data->getYear() < tmpNode->data->getYear())break;
      prevNode = currNode;
      currNode = currNode->next;
    }

    if (prevNode == 0) {
      head = tmpNode;
    }
    else {
      prevNode->next = tmpNode;
    }
    tmpNode->next  = currNode;
  }
  else{
    tmpNode->next = head;
    head = tmpNode;
  }	
}

//Name: getSize
//in: n/a
//out: returns size of list
//Purpose: to return the size of the list
int VehicleList:: getSize() const{
    int size = 0;
	Node* currNode;
	currNode = head;
	while(currNode !=0){
	  size++;
	  currNode = currNode->next;
	}
	return size;	
}

//Name: toString
//in: reference to the eventual ouputString
//out: same as input
//Purpose: build up a string that will eventually serve as output 
//printing off the customer and vehicle info
void VehicleList:: toString(string& outStr){
	Node* currNode;
	currNode = head;
	while(currNode !=0){
		ostringstream makeModel, temp;
		Vehicle* v = currNode->data;
		makeModel << v->getMake() << " " << v->getModel();
		temp << "\t" <<  setw(7) << v->getColour() << " " 
             << v->getYear() << " " << setw(17) << makeModel.str() << " (" 
             << v->getMilage() << "km)" << endl;
        outStr += temp.str();
        currNode = currNode->next;
	}
}
