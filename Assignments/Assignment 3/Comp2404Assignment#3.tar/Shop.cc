#include "Shop.h"


void Shop::addCustomer(Customer* c) { 
	customers.add(c);
	//return 1;
} 


Customer* Shop::getCustomer(int i) const { return (customers.get(i)); } 

CustomerList& Shop::getCustomers() { return customers; }
