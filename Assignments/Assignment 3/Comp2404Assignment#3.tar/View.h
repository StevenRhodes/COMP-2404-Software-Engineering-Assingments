#ifndef VIEW_H
#define VIEW_H

#include "CustomerList.h"
#include "Shop.h"

class View {

    public:
        void mainMenu(int&) const;
        void printCustomers(CustomerList&)  ;
        void pause() const;
	void readInputCust(string*, string*, string*, string*) const;
        int readInputVehicle(Shop&, string*, string*, int*, string*, int*)const;

    private:
        int readInt() const;
};

#endif
