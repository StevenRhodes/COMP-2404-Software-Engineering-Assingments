#include "CustomerList.h"
#include "Customer.h"
#include  <iostream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

CustomerList::CustomerList(): head(0) {}

CustomerList:: ~CustomerList(){
  Node *currNode, *nextNode;
  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
}

//Name: add
//in: customer pointer
//out: n/a
//Purpose: add a customer to the list
void CustomerList:: add(Customer* cust){
  Node* tmpNode = new Node;
  tmpNode->data = cust;
  tmpNode->next = 0;

  Node *currNode, *prevNode =0;

  currNode = head;

  if(currNode !=0){
    while (currNode != 0) { 
      if (currNode->data->getLname() > tmpNode->data->getLname())break;
      prevNode = currNode;
      currNode = currNode->next;
    }

    if (prevNode == 0) {
      head = tmpNode;
    }
    else {
      prevNode->next = tmpNode;
    }
    tmpNode->next  = currNode;
  }
  //if linked list hasn't be started yet:
  else{
    tmpNode->next = head;
    head = tmpNode;
  }
}

//Name: getSize
//in: n/a
//out: returns the size
//Purpose: to get the size of the list
int CustomerList:: getSize() const{
	int size = 0;
	Node* currNode;
	currNode = head;
	while(currNode !=0){
	  size++;
	  currNode = currNode->next;
	}
	return size;
}

//Name: get
//in: customer id
//out: returns a customer with the right id
//Purpose: returns a customer with the right id
Customer* CustomerList:: get(int id)const{	
	Node* currNode;
	currNode = head;
	while(currNode!=0){	 
	  if(currNode->data->getId() == id){
		  return currNode->data;
	  }
	  else{
		  currNode = currNode->next;
	  }
	}
	return NULL; 
}

//Name: toString
//in: reference to a string that will be printed later
//out: same as input
//Purpose: fill up a string to be printed later with info about the customer
// and their vehicles
void CustomerList:: toString(string& outStr) const{
	 Node* currNode;
	 currNode = head;
	 while(currNode!= 0){
		//Temporary storage variables for building up outStr
		ostringstream name, temp;
		Customer* cust = currNode->data;
				
		name << cust->getFname() << " " << cust->getLname();
		
		//Storing Customer info
		temp << "Customer ID " << cust->getId() << endl << endl
         << "    Name: " << setw(40) << name.str() << endl 
         << "    Address: " << setw(37) << cust->getAddress() << endl
         << "    Phone Number: " << setw(32) << cust->getPhoneNumber() << endl;
         outStr += temp.str();
         
         //Going to get vehicle info
         if(cust->getNumVehicles() > 0){
			
		   ostringstream temp2;
		   temp2 << endl << "    " << cust->getNumVehicles() 
                  << " vehicle(s): " << endl << endl;
           outStr += temp2.str();
           cust->getVehicles().toString(outStr);	
	     }
	     //Finishing up the string for this specific customer
	     ostringstream temp3;
		 temp3 << endl << endl;
	     outStr += temp3.str();
         currNode = currNode->next;
	 }
	 
}
