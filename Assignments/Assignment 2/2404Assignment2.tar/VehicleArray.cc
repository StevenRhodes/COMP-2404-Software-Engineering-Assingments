#include "VehicleArray.h"
#include "Vehicle.h"
#include "defs.h"

//VehcileArray default constructor
VehicleArray::VehicleArray(){
	size = 0;
	for (int i=0; i<MAX_VEHICLES; ++i) {
         elements[i]   = 0;
 	}
}

//VehicleArray destructor
VehicleArray::~VehicleArray(){
	for(int i =0; i<size; i++){
			delete(elements[i]);
	}
}

//Function: getSize()
//in: none
//out: int: the size of the vehicle array
//Purpose: to return the size of the vehicle array
int VehicleArray::getSize(){return size;}

//Function: add 
//in: vehicle pointer
//out: int: the status of the function
//purpose: add a vehicle to the vehicle array	
int VehicleArray::add(Vehicle* vehicle){
	if (size >= MAX_VEHICLES) {
		return C_NOK;
    }
    elements[size++] = vehicle;
	return C_OK;
}

//Function: get
//in: the index of the vehicle
//out: return a vehicle pointer
//purpose: to get a specific vehicle from the vehicle array
Vehicle* VehicleArray::get(int i){
	if (i < 0 || i >= size)return 0;
    return elements[i];
}


	

