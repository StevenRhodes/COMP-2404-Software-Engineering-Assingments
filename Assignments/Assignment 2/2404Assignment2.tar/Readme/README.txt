~~~~~~~~~~~~~~~~~~~~~~~~COMP 2404 Assignment#2~~~~~~~~~~~~~~~~~~~~~~~~~~
Author: Steven Rhodes
Student I.D.: 100819007

Purpose: To write a program to keep track of customers at an automotive businessand their vehicles using C++, making use of classes and Object-Oriented Programming ideas.

Source Files used: Customer.cc CustomerArray.cc Shop.cc ShopController.cc Vehicle.cc VehicleArray.cc View.cc main.cc

Header files used: Customer.h CustomerArray.h def.s Shop.h ShopController.h Vehicle.h VehicleArray.h View.h

Other Files: UML diagram, Makefile

Compilation Command: run the make file with command: make

Running/Executing: ./mechanicshop <--- Download the file, compile it with the makefile and run it with this command.
