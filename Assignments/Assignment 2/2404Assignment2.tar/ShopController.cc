#include "ShopController.h"

//ShopController default constructor
ShopController::ShopController() {
	mechanicShop = Shop();
	view = View();
    initCustomers();

}

//This function made by prof
//Function: launch()
//in: none
//out: void
//purpose: to choose what to do with input from user
void ShopController::launch() {

    int choice;

    while (1) {
        choice = -1;
        view.mainMenu(choice);
        
        if (choice == 1) {
            view.printCustomers(mechanicShop.getCustomers());
            view.pause();
        } /*else if (choice == 2) {

        } else if (choice == 3) {

        } else if (choice == 4) {
      
        } ... */
        
        else {
            break;
        }
    }
}

//Function: initCustomers()
//in: none
//out: void
//Purpose: initialize the customers in the shop
void ShopController::initCustomers() {
	
	//Adding Maurice and His Vehicles
	Customer* maurice = new Customer("Maurice", "Maurice", "2600 Colonel By Dr.", "(613)728-9568");
	Vehicle* fiesta = new Vehicle("Ford", "Fiesta", "Red", 2007, 100000);
	maurice->addVehicle(fiesta);
	mechanicShop.addCustomer(maurice);
	
	//Adding Abigail and her Vehicles
	Customer* abigail = new Customer("Abigail", "Abigail", "43 Carling Dr.", "(613)345-6743");
	Vehicle* forester = new Vehicle("Subaru", "Forester", "Green", 2016, 40000);
	abigail->addVehicle(forester);
	mechanicShop.addCustomer(abigail);
	
	//adding Brook and her vehicles
	Customer* brook = new Customer("Brook", "Brook", "1 Bayshore Dr.", "(613)123-7456");
	Vehicle* accord = new Vehicle("Honda", "Accord", "White", 2018, 5000);
	Vehicle* beetle = new Vehicle("Volkswagon", "Beetle", "White", 1972, 5000);
	brook->addVehicle(accord);
	brook->addVehicle(beetle);
	mechanicShop.addCustomer(brook);
	
	//adding Ethan and his vehicles
	Customer* ethan = new Customer("Ethan", "Ethan", "245 Rideau St.", "(613)234-9677");
	Vehicle* camery = new Vehicle("Toyota", "Camery", "Black", 2010, 50000);
	ethan->addVehicle(camery);
	mechanicShop.addCustomer(ethan);
	
	//adding Eve and her vehicles
	Customer* eve = new Customer("Eve", "Eve", "75 Bronson Ave.", "(613)456-2345");
	Vehicle* corolla = new Vehicle("Toyota", "Corolla", "Green", 2013, 80000);
	Vehicle* rav4 = new Vehicle("Toyota", "Rav4", "Gold", 2015, 20000);
	Vehicle* prius = new Vehicle("Toyota", "Prius", "Blue", 2017, 10000);
	eve->addVehicle(corolla);
	eve->addVehicle(rav4);
	eve->addVehicle(prius);
	mechanicShop.addCustomer(eve);
	
	//adding Victor and his vehicles
	Customer* victor = new Customer("Victor", "Victor", "425 O'Connor St.", "(613)432-7622");
	Vehicle* envoy = new Vehicle("GM", "Envoy", "Purple", 2012, 60000);
	Vehicle* escalade = new Vehicle("GM", "Escalade", "Black", 2016, 40000);
	Vehicle* malibu = new Vehicle("GM", "Malibu", "Red", 2015, 20000);
	Vehicle* trail = new Vehicle("GM", "Trailblazer", "Orange", 2012, 90000);
	victor->addVehicle(envoy);
	victor->addVehicle(escalade);
	victor->addVehicle(malibu);
	victor->addVehicle(trail);
	mechanicShop.addCustomer(victor);
	
}
