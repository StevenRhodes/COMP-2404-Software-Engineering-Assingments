#include "Vehicle.h"
#include <string>

//Vehicle Constructor
Vehicle::Vehicle(string vMake, string vModel, string vColour, int vYear, int vMileage){
		make = vMake;
		model = vModel;
		colour = vColour;
		year = vYear;
		mileage = vMileage;
}

//Function: getMake
//in: none
//out:string
//purpose: return the make of the vehicle
string Vehicle::getMake(){return make;}

//Function: getModel
//in: none
//out:string
//purpose: return the model of the vehicle
string Vehicle::getModel(){return model;}

//Function: getColour
//in: none
//out:string
//purpose: return the colour of the vehicle
string Vehicle::getColour(){return colour;}

//Function: getYear
//in: none
//out: int
//purpose: return the year of the vehicle
int Vehicle::getYear(){return year;}

//Function: getMilage
//in: none
//out: int
//purpose: return the mileage of the vehicle
int Vehicle::getMilage(){return mileage;}
