#include "CustomerArray.h"
#include "Customer.h"
#include "defs.h"

//CustomerArray defualt constructor
CustomerArray::CustomerArray(){
	size = 0;
	for (int i=0; i<MAX_CUSTOMERS; ++i) {
           elements[i]   = 0;
 	}
}

//Customer array destructor
CustomerArray::~CustomerArray(){
	for(int i =0; i<size; i++){
			delete(elements[i]);
	}
}

//Function: getSize
//in: none
//out: int: the size of the array
//purpose: return the size of the customer array
int CustomerArray::getSize(){return size;}

//Function: add
//in: customer pointer
//out: int: the status of the function
//purpose: to add a customer to the customer array
int CustomerArray::add(Customer* customer){
	if (size >= MAX_CUSTOMERS ) {
		return C_NOK;
    }
    elements[size++] = customer;
	return C_OK;
	//need to add memory dynamically?
}

//Function: get
//in: int: the index
//out: returns a customer point
//purpose: to get a specific customer from the customer array
Customer* CustomerArray::get(int i){
	if (i < 0 || i >= size)return 0;
    return elements[i];
}





