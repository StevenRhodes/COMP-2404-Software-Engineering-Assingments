#include <iostream>
using namespace std;
#include "Customer.h"
#include <string>

int Customer::nextId = 1000;

//Customer constructor
Customer::Customer(string first, string last, string add, string number){
		id = nextId++; 
		firstName = first;
		lastName = last;
		address = add;
		phoneNumber = number;
		vehicles = VehicleArray();
}

//Function: getId
//in: none
//out: int
//purpose: return the id of the customer
int Customer::getId(){return id;}

//Function: getFname
//in: none
//out: string
//purpose: return the first name of the customer
string Customer::getFname(){return firstName;}

//Function: getLname
//in: none
//out: string
//purpose: return the last name of the customer
string Customer::getLname(){return lastName;}

//Function: getAddress
//in: none
//out: string
//purpose: return the address of the customer
string Customer::getAddress(){return address;}

//Function: getPhoneNumber
//in: none
//out: string
//purpose: return the phone number of the customer
string Customer::getPhoneNumber(){return phoneNumber;}

//Function: getNumVehciles
//in: none
//out: int
//purpose: return the number of vehicles of the customer
int Customer::getNumVehicles(){return vehicles.getSize();}

//Function: getVehicles
//in: none
//out: reference to a vehcile array
//purpose: return a reference to array of vehicles for the customer
VehicleArray& Customer::getVehicles(){return vehicles;}

//Function: addVehicle
//in: a vehicle
//out: int
//purpose: add a vehicle to the customers vehicle array
int Customer::addVehicle(Vehicle* vehicle){
	return vehicles.add(vehicle);
}


