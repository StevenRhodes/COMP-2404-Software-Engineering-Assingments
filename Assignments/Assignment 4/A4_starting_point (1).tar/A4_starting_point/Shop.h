#ifndef SHOP_H
#define SHOP_H

#include "Customer.h"
#include "CustomerList.h"
#include "Mechanic.h"

class Shop{

    public:
        Shop(int=0);
	~Shop();
	
        Customer* getCustomer(int);
        CustomerList& getCustomers();
        Shop& operator+=(Customer*);
        Customer* operator-=(Customer*);
	Mechanic** getMechanics();
	Shop& operator+=(Mechanic*);
	int getNumMechanics();

    private:
        CustomerList customers;
	Mechanic* mechanics[5];
	int numMechanics;

};

#endif
