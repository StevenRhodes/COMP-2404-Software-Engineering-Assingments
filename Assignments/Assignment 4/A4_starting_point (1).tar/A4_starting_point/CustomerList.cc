#include <sstream>
#include <iostream>
#include <iomanip>
using namespace std;
#include <string>


#include "CustomerList.h"

CustomerList::CustomerList() : head(0) { }


CustomerList::~CustomerList()
{
  Node *currNode, *nextNode;

  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
}

/*
void CustomerList::add(Customer* newCust)
{
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newCust;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if (newNode->data->getLname() < currNode->data->getLname())
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;
}
*/

//Name: get
//in: id
//out: Customer pointer
//purpose: get a customer from the customer list
Customer* CustomerList::get(int id) 
{
  Node *currNode = head;

  while (currNode != 0) {
    if(currNode->data->getId() == id) {
      return currNode->data;
    }
    currNode = currNode->next;
  }

  return 0;
}

//Name: getSize
//in: n/a
//out: size
//purpose: get size of customerlist
int CustomerList::getSize() const {
  Node *currNode = head;
  int size = 0;

  while (currNode != 0) {
    currNode = currNode->next;
    size++;
  }
  
  return size;
}

/*Obsolete toString()
void CustomerList::toString(string& outStr)
{
  Node* currNode;
  ostringstream output;

  for (Node* currNode=head; currNode != 0; currNode = currNode->next) {
    ostringstream name;
    name << currNode->data->getFname() << " " << currNode->data->getLname();

    output << "Customer ID " << currNode->data->getId() << endl << endl
           << "    Name: " << setw(40) << name.str() << endl 
           << "    Address: " << setw(37) << currNode->data->getAddress() << endl
           << "    Phone Number: " << setw(32) <<  currNode->data->getPhoneNumber() << endl;
    
    if (currNode->data->getNumVehicles() > 0) {
        output << endl << "    " << currNode->data->getNumVehicles() 
                  << " vehicle(s): " << endl << endl;

        string vehicle_output;
        currNode->data->getVehicles().toString(vehicle_output);
        output << vehicle_output << endl<<endl;
    }

  }
    
  outStr = output.str();

}
*/

ostream& operator<<(ostream& out, CustomerList& cust){
	//ostringstream output;
	
	for(int i =0; i<cust.getSize(); i++){
			out<< *cust[i] << endl <<endl;
	}
	//out << output.str();
	return out;
}

Customer* CustomerList::operator[](int i)const{
	if(i<0 || i>=getSize()){
		return NULL;
	}
	
	Node *currNode = head;
	
	for(int j =0; j< i; ++j){
		currNode = currNode->next;
	}

    return currNode->data;
}

CustomerList& CustomerList::operator+=(Customer* newCust){
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newCust;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if ( *(newNode->data) < *(currNode->data))
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;	
  return *this;
} //may not need a return!


Customer* CustomerList::operator-=(Customer* cust){
	Node *currNode = head;
	Node *prevNode = currNode;
	if(head->next == NULL){
		//maybe shouldn't delete since last node left
		
		delete currNode->data;
		delete currNode;
		head = NULL;
		
		return NULL;
	}
			
	//Need this and maybe drop the currNode =head?
	if( currNode->data == cust){
		head = currNode->next;
		Customer* temp = currNode->data;
		delete(currNode->data);
		delete currNode;
		return temp;
	}
					
	for(int i =0; i<getSize()-1; i++){
		currNode = currNode->next;
		if(currNode->data ==cust){
			//prevNode = currNode;
			prevNode->next = currNode->next;
			Customer* temp = currNode->data;
			delete(currNode->data);
			delete(currNode);
			return temp;
		}
		prevNode = currNode;		
	}
	
	return NULL;	
} //come back to this
	






