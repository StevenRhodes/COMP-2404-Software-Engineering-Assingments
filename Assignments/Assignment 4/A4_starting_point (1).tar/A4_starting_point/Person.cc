#include <string>
#include "Person.h"

Person::Person(string f, string l, string add, string n)
	:firstName(f), lastName(l), address(add), phoneNumber(n)
{
	
}


//Names: get Fname, Lname, address, phoneNumber
//in: n/a
//out: string
//purpose: basic getters
string Person::getFname()const{return firstName;}
string Person::getLname()const{return lastName;}
string Person::getAddress()const{return address;}
string Person::getPhoneNumber()const{return phoneNumber;}
