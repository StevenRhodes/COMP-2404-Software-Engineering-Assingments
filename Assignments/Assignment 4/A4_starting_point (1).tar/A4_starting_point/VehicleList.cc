#include <sstream>
#include <iomanip>
#include <iostream>
using namespace std;
#include <string>

#include "VehicleList.h"

VehicleList::VehicleList() : head(0) { }


VehicleList::~VehicleList()
{
  Node *currNode, *nextNode;

  currNode = head;

  while (currNode != 0) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
}

/* Old add function
void VehicleList::add(Vehicle* newVeh)
{
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newVeh;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if (newNode->data->getYear() > currNode->data->getYear())
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;
}
*/ 

int VehicleList::getSize() const {
  Node *currNode = head;
  int size = 0;

  while (currNode != 0) {
    currNode = currNode->next;
    size++;
  }
  
  return size;
}

/*Obsolete toString
void VehicleList::toString(string& outStr)
{
  Node* currNode;

  ostringstream output;

  for (currNode=head; currNode != 0; currNode = currNode->next) {
    ostringstream make_model;
    make_model << currNode->data->getMake() << " " << currNode->data->getModel();

    output << "\t" << setw(7) << currNode->data->getColour() << " " 
                 << currNode->data->getYear() << " " << setw(17) << make_model.str() << " (" 
                 << currNode->data->getMilage() << "km)" << endl;

  }
  
  outStr = output.str();
}
*/

ostream& operator<<(ostream& out , VehicleList& veh){
	//ostringstream output;
	
	for(int i =0; i<veh.getSize(); i++){
			out<< *veh[i];
	}
	//out << output.str();
	return out;
	//Need to add to a string perhaps???
	//Come back to this!
}

VehicleList& VehicleList::operator+=(Vehicle* newVeh){
  Node *currNode, *prevNode;
  Node* newNode = new Node;
  newNode->data = newVeh;
  newNode->next = 0;

  currNode = head;
  prevNode = 0;

  while (currNode != 0) {
    if ( *(newNode->data) > *(currNode->data))
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == 0) {
    head = newNode;
  }
  else {
    prevNode->next = newNode;
  }

  newNode->next = currNode;	
  return *this; //Return a vehilce& or a VehicleList&  ????
}



Vehicle* VehicleList::operator-=(Vehicle* veh){
	Node* currNode = head;
	Node* prevNode = currNode;
	if(head->next == NULL){
		delete currNode->data;
		delete currNode;
		head = NULL;
		//maybe shouldn't delete since last node left
		return NULL;
	}
			
	//Need this and maybe drop the currNode =head?
	if( currNode->data == veh){
		head = currNode->next;
		Vehicle* temp = currNode->data;
		delete(currNode->data);
		delete currNode;
		return temp;
	}
					
	for(int i =0; i<getSize()-1; i++){
		currNode = currNode->next;
		if(currNode->data ==veh){
			//prevNode = currNode;
			prevNode->next = currNode->next;
			Vehicle* temp = currNode->data;
			delete(currNode->data);
			delete currNode;
			return temp;
		}
		prevNode = currNode;		
	}
	
	return NULL;	
}

Vehicle* VehicleList::operator[](int i)const{
	if(i<0 || i>=getSize()){
		return NULL;
	}
	
	Node *currNode = head;
	
	for(int j =0; j< i; ++j){
		currNode = currNode->next;
	}

    return currNode->data;
}







