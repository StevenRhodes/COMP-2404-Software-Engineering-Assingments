#ifndef CUSTOMERLIST_H
#define CUSTOMERLIST_H

#include "Customer.h"


class CustomerList
{

  friend ostream& operator<<(ostream& , CustomerList&);

  class Node
  {
    friend class CustomerList;
    private:
      Customer* data;
      Node*    next;
  };

  public:
    CustomerList();
    ~CustomerList();
    void add(Customer*);
    void toString(string&);
    int getSize() const;
    Customer* get(int);
    Customer* operator [](int)const;
    CustomerList& operator +=(Customer*);
    Customer*operator -=(Customer*);

  private:
    Node* head;

};

#endif
