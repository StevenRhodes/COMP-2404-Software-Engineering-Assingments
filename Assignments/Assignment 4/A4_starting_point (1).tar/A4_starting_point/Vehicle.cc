#include "Vehicle.h"
#include <iostream>
#include <sstream>
#include <iomanip>

Vehicle::Vehicle(string ma, string mo, string col, int y, int m) { 
    make = ma;
    model = mo;
    colour = col;
    year = y;
    mileage = m;
}

string  Vehicle::getMake() const     { return make; }
string  Vehicle::getModel() const    { return model; }
string  Vehicle::getColour() const   { return colour; }
int     Vehicle::getYear() const     { return year; }
int     Vehicle::getMilage() const   { return mileage; }

ostream& operator<<(ostream& out, Vehicle& veh){
		//ostringstream output;
		ostringstream make_model;
        make_model << veh.getMake() << " " << veh.getModel();

        out << "\t" << setw(7) << veh.getColour() << " " 
                 << veh.getYear() << " " << setw(17) << make_model.str() << " (" 
                 << veh.getMilage() << "km)" << endl;
		//out << output.str();
		return out;
}

bool Vehicle::operator>(Vehicle& veh)const{
	return getYear() > veh.getYear();
}
bool Vehicle::operator<(Vehicle& veh)const{
	return getYear() < veh.getYear();
}
