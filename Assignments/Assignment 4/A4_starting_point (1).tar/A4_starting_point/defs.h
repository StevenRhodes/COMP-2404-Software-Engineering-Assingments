#ifndef DEFS_H
#define DEFS_H

#define MAX_VEHICLES    4
#define MAX_CUSTOMERS   6

#define C_OK            0
#define C_NOK          -1

#endif
