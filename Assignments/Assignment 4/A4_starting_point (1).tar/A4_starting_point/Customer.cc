#include <iostream>
#include <sstream>
using namespace std;
#include "Customer.h"
#include <iomanip>
#include "Person.h"


int Customer::nextId = 1000;

/*
Customer::Customer(string fname, string lname, string add, string pnum) : 
        id(Customer::nextId++) { 
    firstName   = fname;
    lastName    = lname;
    address     = add;
    phoneNumber = pnum;
}*/

Customer::Customer(string fname, string lname, string add, string pnum)
	:Person(fname, lname, add, pnum), id(Customer::nextId++)
{
	
}

int           Customer::getId() const           { return id; }
//string        Customer::getFname() const        { return firstName; }
//string        Customer::getLname() const        { return lastName; }
//string        Customer::getAddress() const      { return address; }
//string        Customer::getPhoneNumber() const  { return phoneNumber; }
int           Customer::getNumVehicles() const  { return vehicles.getSize(); }
VehicleList&  Customer::getVehicles()           { return vehicles; }
//void          Customer::addVehicle(Vehicle* v)  { vehicles.add(v); }

ostream& operator<<(ostream& out, Customer& cust){   
    ostringstream name;
    name << cust.getFname() << " " << cust.getLname();

    out << "Customer ID " << cust.getId() << endl << endl
           << "    Name: " << setw(40) << name.str() << endl 
           << "    Address: " << setw(37) << cust.getAddress() << endl
           << "    Phone Number: " << setw(32) <<  cust.getPhoneNumber() << endl;
    
    if (cust.getNumVehicles() > 0) {
        out << endl << "    " << cust.getNumVehicles() 
                  << " vehicle(s): " << endl << endl;

        //string vehicle_output;
        //currNode->data->getVehicles().toString(vehicle_output);
        //output << vehicle_output << endl<<endl;
        
        for(int i =0; i<cust.getNumVehicles(); i++){
            out << *cust.getVehicles()[i];
        }
    }

    return out;
}

Customer& Customer::operator+=(Vehicle* veh){
		vehicles += veh;
		return *this;
}
bool Customer::operator>(Customer& cust)const{
	return getLname() > cust.getLname();
}
bool Customer::operator<(Customer& cust)const{
	return getLname() < cust.getLname();
}

