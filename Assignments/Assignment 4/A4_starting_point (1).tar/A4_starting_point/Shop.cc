#include "Shop.h"
#include "defs.h"


Shop::Shop(int numMechs):numMechanics(numMechs){}

Shop::~Shop()
{
	for(int i =0; i<numMechanics; i++){
		delete mechanics[i];
	}
	delete [] *mechanics;
}
Customer* Shop::getCustomer(int i)  { return customers.get(i); } 

CustomerList& Shop::getCustomers() { return customers; }

//Name: getMechanics
//in: n/a
//out: Array of mechanic pointers
//purpose: get an array of mechanics from the shop
Mechanic** Shop::getMechanics() {return mechanics;} 

int Shop::getNumMechanics(){return numMechanics;}

Shop& Shop::operator+=(Customer* cust){
	customers+= cust;
	return *this;
}


Customer* Shop::operator-=(Customer* cust){
	return customers-= cust;
	
}

Shop& Shop::operator+=(Mechanic* mech){
		if(numMechanics<5){
				mechanics[numMechanics] = mech;
				numMechanics++;
				return *this;
		}
		return *this;
		
}


