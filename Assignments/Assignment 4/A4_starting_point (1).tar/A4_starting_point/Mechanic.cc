#include <iostream>
#include <sstream>
using namespace std;
#include "Customer.h"
#include <iomanip>
#include "Person.h"
#include "Mechanic.h"

int Mechanic::nextId = 5000;

Mechanic::Mechanic(string f, string l, string add, string numb, int sal)
	: Person(f, l, add, numb), salary(sal), id(Mechanic::nextId++){}

//Name: getId
//in: n/a
//out: id
//purpose: get a mechanic's id	
int Mechanic::getId()const{return id;}

//Name: get
//in: n/a
//out: salary
//purpose: get a mechanic's salary
int Mechanic::getSalary()const{return salary;}

ostream& operator<<(ostream& out, Mechanic& mech){
		    ostringstream name;
    name << mech.getFname() << " " << mech.getLname();

    out << "Customer ID " << mech.getId() << endl << endl
           << "    Name: " << setw(40) << name.str() << endl 
           << "    Address: " << setw(37) << mech.getAddress() << endl
           << "    Phone Number: " << setw(32) <<  mech.getPhoneNumber() << endl
           << "    Salary: " <<setw(38) << mech.getSalary() << endl;
    
    return out;
}
