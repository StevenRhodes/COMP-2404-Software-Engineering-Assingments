#include "VehicleFactory.h"
#include <string>
#include <sstream>
using namespace std;

Vehicle* VehicleFactory::create(string make, string model, string colour, int year, int mileage){
   	Car *newCar;
	newCar = new Car(make, model, colour,year, mileage);
	return newCar;
}

Vehicle* VehicleFactory::create(string make, string model, string colour, int year, int mileage, int axles){
	Truck *newTruck;
	newTruck = new Truck(make, model, colour, year, mileage, axles);
	return newTruck;
}

Vehicle* VehicleFactory::create(string make, string model, string colour, int year, int mileage, bool sideCar){
	Motorcycle *newCycle;
	newCycle = new Motorcycle(make, model, colour, year, mileage, sideCar);
	return newCycle;
}
