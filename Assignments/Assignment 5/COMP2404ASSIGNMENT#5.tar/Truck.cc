#include <iostream>
using namespace std;
#include "Truck.h"
#include <string>

Truck::Truck(string ma , string mo, string col , int y , int m, int ax) :
	Vehicle(ma, mo, col, y, m) , axles(ax){ }

int Truck::getAxles()const{return axles;}

string Truck::toString(){
    ostringstream output;
    ostringstream make_model;
    make_model << this->getMake() << " " << this->getModel();

    output << "\t" << "TRUCK: " <<setw(13) << this->getColour() << " " << this->getYear() << " " << setw(17);
    output << make_model.str() << " (" << this->getMilage() << "km)," << this->getAxles()<< " axles"<< endl;	
	
	return output.str();	
	
}
