#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"
#include <string>
#include <iostream>
using namespace std;

class Truck : public Vehicle{
	
	public:
		Truck(string, string, string, int , int, int );
		string toString();
		int getAxles() const;

	private:
		int axles;
};




#endif