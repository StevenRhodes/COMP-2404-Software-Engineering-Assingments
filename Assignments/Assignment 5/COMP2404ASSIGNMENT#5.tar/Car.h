#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"
#include <string>
#include <iostream>
using namespace std;

class Car : public Vehicle{
	
	public:
		Car(string , string, string, int, int);
		string toString();
};




#endif