#include <iostream>
using namespace std;
#include "Car.h"
#include <string>

Car::Car(string ma , string mo, string col , int y , int m) :
	Vehicle(ma, mo, col, y, m) { }

string Car::toString(){
    ostringstream output;
    ostringstream make_model;
    make_model << this->getMake() << " " << this->getModel();

    output <<  "\t" << "CAR: " << setw(15) << this->getColour() << " " << this->getYear() << " " << setw(17);
    output << make_model.str() << " (" << this->getMilage() << "km)" << endl;	
	
	return output.str();
}
