#ifndef VIEW_H
#define VIEW_H

//#include "CustomerList.h"
#include "Mechanic.h"
#include "LinkedList.h"
#include "Customer.h"
#include "Vehicle.h"

class View {

    public:
        void mainMenu(int&);
        void printCustomers(LinkedList<Customer*>&) const;
        void pause() const;
        void promptUserInfo(string&, string&, string&, string&);
        void promptUserId(int&);
        void displayInvalid();
        void promptVehicleInfo(string&, string&, string&, int&, int&);
	void promptVehicleInfo(string&, string&, string&, int&, int&, int&);
	void promptVehicleInfo(string&, string&, string&, int&, int&, bool&);
        void promptVehicle(int, int&);
        void printMechanics(Mechanic**, int) const;
	void printMechanics(LinkedList<Mechanic*>&)const;
	void promptVehicleType(string&);
    private:
        int readInt() const;
};

#endif
