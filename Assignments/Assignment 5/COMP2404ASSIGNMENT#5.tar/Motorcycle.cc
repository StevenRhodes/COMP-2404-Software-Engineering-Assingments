#include <iostream>
using namespace std;
#include "Motorcycle.h"
#include <string>

Motorcycle::Motorcycle(string ma , string mo, string col , int y , int m, bool s) :
	Vehicle(ma, mo, col, y, m), sideCar(s) { }

bool Motorcycle::hasSideCar(){return sideCar;}


string Motorcycle::toString(){
    ostringstream output;
    ostringstream make_model;
    ostringstream side;
    
    if(this->hasSideCar() == true){
			side << "has a sidecar";
	}
	else{
			side << "no sidecar";
	}
    make_model << this->getMake() << " " << this->getModel();

    output << "\t" << "MOTORCYCLE: " << setw(8) << this->getColour() << " " << this->getYear() << " " << setw(17);
    output << make_model.str() << " (" << this->getMilage() << "km)," << side.str() <<endl;	
	
	return output.str();	
	
	
	
}
