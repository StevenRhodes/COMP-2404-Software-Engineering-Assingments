#ifndef VEHICLEFACTORY_H
#define VEHICLEFACTORY_H
#include "Car.h"
#include "Truck.h"
#include "Motorcycle.h"
using namespace std;
#include <string>

class VehicleFactory{
	
	public:
		virtual Vehicle* create(string, string, string, int,int);
		virtual Vehicle* create(string, string, string, int,int, int);
		virtual Vehicle* create(string, string, string, int,int, bool );

};


#endif