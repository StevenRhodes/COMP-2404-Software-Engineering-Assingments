==============COMP 2404: Assignment #5=================
Author: Steven Rhodes
Student I.D.: 100819007

Purpose: To write a program to keep track of customers and mechanics
at an automotive business and their vehicles, using C++
with use of LinkedLists as well as usage of Object Oriented
principles such as templates, design patterns such as factory, and abstract
classes.

Source Files: Customer.cc CustomerList.cc Shop.cc ShopController.c
Vehicle.cc VehicleList.cc View.cc Main.cc Mechanic.cc Person.cc Car.cc. Motorcycle.cc
Truck.cc VehicleFactory.cc

Header Files: Customer.h CustomerList.h Shop.h ShopController.h
Vehicle.h VehicleList.h View.h Person.h Mechanic.h LinkedList.h Car.h
Truck.h Motorcycle.h VehicleFactory.h

Other Files: Makefile defs.h

Compilation Command: run the make file with the command: make

Running/Execution: ./mechanicshop <--Download the file, compile with
the makefile and then run with this command.



