#ifndef SHOPCONTROLLER_H
#define SHOPCONTROLLER_H

#include "View.h"
#include "Shop.h"
#include "VehicleFactory.h"
#include "LinkedList.h"
using namespace std;

class ShopController {

    public:
        ShopController();
        void launch();
    private:
	VehicleFactory vehicleFactory;
        Shop mechanicShop;
        View view;
        void initShop();
};

#endif
