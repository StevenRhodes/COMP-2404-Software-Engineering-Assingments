#ifndef MOTORCYCLE_H
#define MOTORCYCLE_H

#include "Vehicle.h"
#include <string>
#include <iostream>
using namespace std;

class Motorcycle : public Vehicle{
	
	public:
		Motorcycle(string, string, string, int, int, bool );
		string toString();
		bool hasSideCar();

	private:
		bool sideCar;
};




#endif