#include "Shop.h"
#include "defs.h"
#include <iostream>

Shop::Shop()  { }

Shop::~Shop() {
    for (int i=0; i < mechanics.getSize(); i++) 
        delete mechanics[i];
}

//void Shop::addCustomer(Customer* c) { customers += c; }
Shop& Shop::operator+=(Customer* c) { 
    customers += c; 
    return *this;
}

Shop& Shop::operator-=(Customer* c) { 
    customers -= c; 
    return *this;
}

Customer* Shop::getCustomer(int j)  { 
	for (int i =0; i<customers.getSize() ; i++){
		
		if(customers[i]->getId() == j){
			
			return customers[i];
		}
	}
	return 0;
}
	//return customers.get(i); } 
//need to find another way to get the customer. use []?

LinkedList<Customer*>& Shop::getCustomers() { return customers; }

/* Old +=
Shop& Shop::operator+=(Mechanic* m) {    
    if(numMechanics < MAX_MECHANICS) {
        mechanics[numMechanics] = m;
        numMechanics++;
    }

    return *this;
}
*/

Shop& Shop::operator+=(Mechanic* m){
		
		if(mechanics.getSize()<MAX_MECHANICS){
			mechanics += m;
				
		}
		
		return *this;
}

//int Shop::getNumMechanics()     { return numMechanics; }
LinkedList<Mechanic*>& Shop::getMechanics()  { return mechanics; }
